#!/bin/bash
# Di chuyển đến thư mục chứa script để đảm bảo đường dẫn tài nguyên luôn đúng
cd "$(dirname "$0")"

# Thiết lập biến môi trường để chương trình ưu tiên tìm thư viện trong thư mục này
export LD_LIBRARY_PATH=.

# Chạy game
./shooter_game
